
const Form = () =>{
    return(
        
    <form>
        <h1>Registrar Usuario</h1>
        <div>
        <label htmlFor="email">Email</label>
        <input type="text" name="email" id="email" required placeholder="user@example.com"></input>
        </div>
        <div>
        <label htmlFor="password">Password</label>
        <input type="password" name="password"  required></input> 
        </div>
        <input type="submit" placeholder="Registrar"/>
    </form>
    )
}

export default Form;