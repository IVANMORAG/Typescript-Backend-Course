export interface User{
    email:string;
    password:string;
    _id:string;
    _v:string;
}