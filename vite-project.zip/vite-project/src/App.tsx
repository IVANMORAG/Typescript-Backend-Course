
import Form from "./components/Form"
import type { Props }  from "./Types/Props"

const App = (props: Props) => {
  return (
    <Form/>
  )
}

export default App